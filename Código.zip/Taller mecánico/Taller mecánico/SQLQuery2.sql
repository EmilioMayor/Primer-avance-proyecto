USE Proyectocs;

 CREATE TABLE tb_login (
	id INT IDENTITY(1,1) PRIMARY KEY,
    nombre_usuario varchar(50),
	contrase�a varchar(50)
);
INSERT INTO tb_login (nombre_usuario, contrase�a) VALUES ('Ariana Alomia', '12345');
INSERT INTO tb_login (nombre_usuario, contrase�a) VALUES ('Emilio Mayor', '98765');

CREATE TABLE tb_cliente_vehiculo(
    id INT IDENTITY(1,1) PRIMARY KEY,
    nombres VARCHAR(100) NOT NULL,
    apellidos VARCHAR(100) NOT NULL,
    cedula VARCHAR(10) NOT NULL,
    celular numeric(10) NOT NULL,
    correo VARCHAR(100) NOT NULL,
    placa VARCHAR(100) NOT NULL,
    marca VARCHAR(100) NOT NULL,
    modelo VARCHAR(100) NOT NULL,
    color VARCHAR(100) NOT NULL
);

select * from tb_cliente_vehiculo

insert into tb_cliente_vehiculo(nombres, apellidos, cedula, celular, correo, placa, marca, modelo, color)
values('Michael Andres', 'Mora Acosta', '0902658950', 0987654321,'michael@gmail.com', 'MCB-250', 'Honda', 'City', 'Negro');

insert into tb_cliente_vehiculo(nombres, apellidos, cedula, celular, correo, placa, marca, modelo, color)
values('Luis Miguel', 'Parras Acosta', '0945968522', 0563226698,'luismi@hotmail.com', 'AAC-023', 'Chevrolet', 'Corvette Z06 2023', 'Negro');

CREATE TABLE tb_mecanico(
    id INT IDENTITY(1,1) PRIMARY KEY,
    nombres VARCHAR(100) NOT NULL,
    apellidos VARCHAR(100) NOT NULL,
    cedula VARCHAR(10) NOT NULL,
    celular numeric(10) NOT NULL,
    correo VARCHAR(100) NOT NULL
);

select * from tb_mecanico;

insert into tb_mecanico(nombres, apellidos, cedula, celular, correo)
values('Juan Andres', 'Mendoza Acosta', '0902658950', 0987654321,'juan@gmail.com');

insert into tb_mecanico(nombres, apellidos, cedula, celular, correo)
values('Luis Mateo', 'Parrales Anchundia', '0945968522', 0563226698,'luis2mateo@hotmail.com');


CREATE TABLE tb_servicios (
    id INT IDENTITY(1,1) PRIMARY KEY,
    nombre VARCHAR(50),
    total FLOAT
);
select * from tb_servicios;

CREATE TABLE tb_mantenimiento(
    id INT IDENTITY(1,1) PRIMARY KEY,
	fecha Date NOT NULL,
	nombre_cliente VARCHAR(100) NOT NULL,
	placa_vehiculo VARCHAR(100) NOT NULL,
	marca_vehiculo VARCHAR(100) NOT NULL,
	modelo_vehiculo VARCHAR(100) NOT NULL,
	color_vehiculo VARCHAR(100) NOT NULL,
	nombre_mecanico VARCHAR(100) NOT NULL,
    trabajos VARCHAR(150) NOT NULL,
	nombre_servicios VARCHAR(100),
	Total_servicios FLOAT,
	Tipo_mantenimiento VARCHAR(100) NOT NULL,
	total_tipo_mat FLOAT NOT NULL,
    subtotal FLOAT NOT NULL,
    total_pagar FLOAT NOT NULL,   	
);

--------------PROCEDIMIENTOS ALMACENADOS--------------PROCEDIMIENTOS ALMACENADOS--------------
---INICIO SESION
GO
CREATE PROCEDURE SP_LOGIN_USUARIO
    @nombre_usuario VARCHAR(50),
    @contrase�a VARCHAR(50)
AS
BEGIN
    SELECT TOP 1 Id, Nombre_usuario
    FROM tb_login
    WHERE nombre_usuario = @nombre_usuario AND contrase�a = @contrase�a;
END


GO
CREATE PROCEDURE SP_GET_USUARIO AS
	SELECT * FROM tb_login
GO
EXEC SP_GET_USUARIO;


GO
CREATE PROCEDURE SP_CREA_USUARIO
    @nombre_usuario varchar(50),
    @contrase�a varchar(50)
AS
BEGIN
 
    INSERT INTO tb_login (nombre_usuario, contrase�a) VALUES (@nombre_usuario, @contrase�a);
END;

EXEC SP_CREA_USUARIO 'PRUEBA', '123';
SELECT * FROM tb_login


GO
CREATE PROCEDURE SP_ACTUALIZA_USUARIO
	@id int,
	@nombre_usuario varchar(50),
	@contrase�a varchar(50)
AS
	UPDATE tb_login
	SET contrase�a = @contrase�a,
	nombre_usuario = @nombre_usuario
	WHERE id = @id;
GO
SELECT * FROM tb_login

GO
CREATE PROCEDURE SP_ELIMINA_USUARIO
	@IdNombre_usuario int
AS
	DELETE FROM tb_login WHERE id = @IdNombre_usuario;
GO
EXEC SP_ELIMINA_USUARIO 6;




----CLIENTE_VEHICULO
GO
CREATE PROCEDURE SP_GET_CLIENTE_VEHICULO AS
	SELECT * FROM tb_cliente_vehiculo
GO
EXEC SP_GET_CLIENTE_VEHICULO;


GO
CREATE PROCEDURE SP_CREA_CLIENTE_VEHICULO
	@nombres varchar(100),
	@apellidos varchar(100),
	@cedula varchar(10),
	@celular numeric(10),
	@correo varchar(100),
	@placa varchar(100),
	@marca varchar(100),
	@modelo varchar(100),
	@color varchar(100)
AS
	INSERT INTO tb_cliente_vehiculo(nombres, apellidos, cedula, celular, correo, placa, marca, modelo, color)
	VALUES(@nombres, @apellidos, @cedula, @celular, @correo, @placa, @marca, @modelo, @color);
GO
EXEC SP_CREA_CLIENTE_VEHICULO 'Maria Lucia', 'Toala Zambrano', '0945369855', 0963586692,'mon.lucia@hotmail.com', 'JHW-456', 'Jeep', 'Avenger', 'Amarillo' ;
SELECT * FROM tb_cliente_vehiculo


GO
CREATE PROCEDURE SP_ACTUALIZA_CLIENTE_VEHICULO
	@id int,
	@nombres varchar(100),
	@apellidos varchar(100),
	@cedula varchar(10),
	@celular numeric(10),
	@correo varchar(100),
	@placa varchar(100),
	@marca varchar(100),
	@modelo varchar(100),
	@color varchar(100)
AS
	UPDATE tb_cliente_vehiculo
	SET nombres = @nombres,
	apellidos = @apellidos,
	cedula = @cedula,
	celular = @celular,
	correo = @correo,
	placa = @placa,
	marca = @marca,
	modelo = @modelo,
	color = @color
	WHERE id = @id;
GO
SELECT * FROM tb_cliente_vehiculo

GO
CREATE PROCEDURE SP_ELIMINA_CLIENTE_VEHICULO
	@IdClienteVehiculo int
AS
	DELETE FROM tb_cliente_vehiculo WHERE id = @IdClienteVehiculo;
GO
EXEC SP_ELIMINA_CLIENTE_VEHICULO 5;





-----MECANICO
GO
CREATE PROCEDURE SP_GET_MECANICO AS
	SELECT * FROM tb_mecanico
GO
EXEC SP_GET_MECANICO;


GO
CREATE PROCEDURE SP_CREA_MECANICO
	@nombres varchar(100),
	@apellidos varchar(100),
	@cedula varchar(10),
	@celular numeric(10),
	@correo varchar(100)
AS
	INSERT INTO tb_mecanico(nombres, apellidos, cedula, celular, correo)
	VALUES(@nombres, @apellidos, @cedula, @celular, @correo);
GO
EXEC SP_CREA_MECANICO 'Monica Lucia', 'Torres Zambrano', '0945369855', 0963586692,'mon.lucia@hotmail.com';
SELECT * FROM tb_mecanico


GO
CREATE PROCEDURE SP_ACTUALIZA_MECANICO
	@id int,
	@nombres varchar(100),
	@apellidos varchar(100),
	@cedula varchar(10),
	@celular numeric(10),
	@correo varchar(100)
AS
	UPDATE tb_mecanico
	SET nombres = @nombres,
	apellidos = @apellidos,
	cedula = @cedula,
	celular = @celular,
	correo = @correo
	WHERE id = @id;
GO
SELECT * FROM tb_mecanico

GO
CREATE PROCEDURE SP_ELIMINA_MECANICO
	@IdMecanico int
AS
	DELETE FROM tb_mecanico WHERE id = @IdMecanico;
GO
EXEC SP_ELIMINA_MECANICO 5;




---SERVICIOS
GO
CREATE PROCEDURE SP_GET_SERVICIOS AS
	SELECT * FROM tb_servicios
GO
EXEC SP_GET_SERVICIOS;


GO
CREATE PROCEDURE SP_CREA_SERVICIOS
	@nombre varchar(100),
	@total numeric(3)
AS
	INSERT INTO tb_servicios(nombre, total)
	VALUES(@nombre, @total);
GO
SELECT * FROM tb_servicios


GO
CREATE PROCEDURE SP_ACTUALIZA_SERVICIOS
	@id int,
	@nombre varchar(100),
	@total numeric(3)
AS
	UPDATE tb_servicios
	SET nombre = @nombre,
	total = @total
	WHERE id = @id;
GO
SELECT * FROM tb_servicios


GO
CREATE PROCEDURE SP_ELIMINA_SERVICIOS
	@IdServicio int
AS
	DELETE FROM tb_servicios WHERE id = @IdServicio;
GO


--MANTENIMIENTO
GO
CREATE PROCEDURE SP_GET_MANTENIMIENTO AS
	SELECT * FROM tb_mantenimiento
GO
EXEC SP_GET_MANTENIMIENTO;

GO
CREATE PROCEDURE SP_CREA_MANTENIMIENTO
    @fecha DATE,
    @nombre_cliente VARCHAR(100),
    @placa_vehiculo VARCHAR(100),
    @marca_vehiculo VARCHAR(100),
    @modelo_vehiculo VARCHAR(100),
    @color_vehiculo VARCHAR(100),
    @nombre_mecanico VARCHAR(100),
    @trabajos VARCHAR(150),
    @nombre_servicios VARCHAR(100),
    @Total_servicios FLOAT,
    @Tipo_mantenimiento VARCHAR(100),
    @total_tipo_mat FLOAT,
    @subtotal FLOAT,
    @total_pagar FLOAT
AS
BEGIN
    INSERT INTO tb_mantenimiento (
        fecha,
        nombre_cliente,
        placa_vehiculo,
        marca_vehiculo,
        modelo_vehiculo,
        color_vehiculo,
        nombre_mecanico,
        trabajos,
        nombre_servicios,
        Total_servicios,
        Tipo_mantenimiento,
        total_tipo_mat,
        subtotal,
        total_pagar
    )
    VALUES (
        @fecha,
        @nombre_cliente,
        @placa_vehiculo,
        @marca_vehiculo,
        @modelo_vehiculo,
        @color_vehiculo,
        @nombre_mecanico,
        @trabajos,
        @nombre_servicios,
        @Total_servicios,
        @Tipo_mantenimiento,
        @total_tipo_mat,
        @subtotal,
        @total_pagar
    );
END;

GO
CREATE PROCEDURE SP_ACTUALIZA_MANTENIMIENTO
    @id INT,
    @fecha DATE,
    @nombre_cliente VARCHAR(100),
    @placa_vehiculo VARCHAR(100),
    @marca_vehiculo VARCHAR(100),
    @modelo_vehiculo VARCHAR(100),
    @color_vehiculo VARCHAR(100),
    @nombre_mecanico VARCHAR(100),
    @trabajos VARCHAR(150),
    @nombre_servicios VARCHAR(100),
    @Total_servicios FLOAT,
    @Tipo_mantenimiento VARCHAR(100),
    @total_tipo_mat FLOAT,
    @subtotal FLOAT,
    @total_pagar FLOAT
AS
BEGIN
    UPDATE tb_mantenimiento
    SET
        fecha = @fecha,
        nombre_cliente = @nombre_cliente,
        placa_vehiculo = @placa_vehiculo,
        marca_vehiculo = @marca_vehiculo,
        modelo_vehiculo = @modelo_vehiculo,
        color_vehiculo = @color_vehiculo,
        nombre_mecanico = @nombre_mecanico,
        trabajos = @trabajos,
        nombre_servicios = @nombre_servicios,
        Total_servicios = @Total_servicios,
        Tipo_mantenimiento = @Tipo_mantenimiento,
        total_tipo_mat = @total_tipo_mat,
        subtotal = @subtotal,
        total_pagar = @total_pagar
    WHERE id = @id;
END;

GO
CREATE PROCEDURE SP_ELIMINA_MANTENIMIENTO
	@IdMantenimiento int
AS
	DELETE FROM tb_mantenimiento WHERE id = @IdMantenimiento;
GO


---NOMBRES COMPLETOS
GO
CREATE PROCEDURE SP_GET_NOMBRES_MECANICO
AS
BEGIN
SELECT CONCAT (Nombres, ' ', Apellidos) AS NombreCompleto From tb_mecanico;
END;