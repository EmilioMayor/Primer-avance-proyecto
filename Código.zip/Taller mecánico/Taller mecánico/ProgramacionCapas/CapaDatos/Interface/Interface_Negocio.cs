﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaDatos.ExecuteSQL;

namespace CapaDatos.Interface
{
    public class Interface_Negocio
    {
        private ExecuteSQL.ExecuteSQL obj_bd = new ExecuteSQL.ExecuteSQL();
        public Interface_Negocio() { }

        public DataTable getListaUsuarios()
        {
            List<CD_Parameter_SP> lista = new List<CD_Parameter_SP>();
            return obj_bd.ExecuteSPQuery("SP_GET_USUARIO", lista);
        }
        public DataTable getListaClienteVehiculo()
        {
            List<CD_Parameter_SP> lista = new List<CD_Parameter_SP>();
            return obj_bd.ExecuteSPQuery("SP_GET_CLIENTE_VEHICULO", lista);
        }
        public DataTable getListaMecanico()
        {
            List<CD_Parameter_SP> lista = new List<CD_Parameter_SP>();
            return obj_bd.ExecuteSPQuery("SP_GET_MECANICO", lista);
        }


        public DataTable getListaServiciosAdicionales()
        {
            List<CD_Parameter_SP> lista = new List<CD_Parameter_SP>();
            return obj_bd.ExecuteSPQuery("SP_GET_SERVICIOS", lista);
        }

        //OBTENER NOMBRES COMPLETOS 
        public DataTable getNombresCompletosMecanico()
        {
            List<CD_Parameter_SP> lista = new List<CD_Parameter_SP>();
            return obj_bd.ExecuteSPQuery("SP_GET_NOMBRES_MECANICO", lista);
        }




        //SP LOGIN      
        public bool CrearUsuario(List<CD_Parameter_SP> lista)
        {
            try
            {
                return obj_bd.ExecuteSPNonQuery("SP_CREA_USUARIO", lista);
            }
            catch (Exception ex)
            {
                throw new Exception("Error al Crear Usuario " + ex.Message);
            }
        }
        public bool ActualizarUsuario(List<CD_Parameter_SP> lista)
        {
            try
            {
                return obj_bd.ExecuteSPNonQuery("SP_ACTUALIZA_USUARIO", lista);
            }
            catch (Exception ex)
            {
                throw new Exception("Error al Actualizar Usuario " + ex.Message);
            }
        }
        public bool EliminarUsuario(List<CD_Parameter_SP> lista)
        {
            try
            {
                return obj_bd.ExecuteSPNonQuery("SP_ELIMINA_USUARIO", lista);
            }
            catch (Exception ex)
            {
                throw new Exception("Error al Eliminar Usuario " + ex.Message);
            }
        }


        //SP CLIENTE_VEHICULO
        public bool CreaClienteVehiculo(List<CD_Parameter_SP> lista)
        {
            try
            {
                return obj_bd.ExecuteSPNonQuery("SP_CREA_CLIENTE_VEHICULO", lista);
            }
            catch (Exception ex)
            {
                throw new Exception("Error al Crear Cliente y vehiculo " + ex.Message);
            }
        }

        public bool ActualizarClienteVehiculo(List<CD_Parameter_SP> lista)
        {
            try
            {
                return obj_bd.ExecuteSPNonQuery("SP_ACTUALIZA_CLIENTE_VEHICULO", lista);
            }
            catch (Exception ex)
            {
                throw new Exception("Error al Actualizar Cliente y vehiculo " + ex.Message);
            }
        }
        public bool EliminaClienteVehiculo(List<CD_Parameter_SP> lista)
        {
            try
            {
                return obj_bd.ExecuteSPNonQuery("SP_ELIMINA_CLIENTE_VEHICULO", lista);
            }
            catch (Exception ex)
            {
                throw new Exception("Error al Eliminar Cliente y vehiculo " + ex.Message);
            }
        }


        //SP MECANICO
        public bool CreaMecanico(List<CD_Parameter_SP> lista)
        {
            try
            {
                return obj_bd.ExecuteSPNonQuery("SP_CREA_MECANICO", lista);
            }
            catch (Exception ex)
            {
                throw new Exception("Error al Crear Mecanico " + ex.Message);
            }
        }

        public bool ActualizarMecanico(List<CD_Parameter_SP> lista)
        {
            try
            {
                return obj_bd.ExecuteSPNonQuery("SP_ACTUALIZA_MECANICO", lista);
            }
            catch (Exception ex)
            {
                throw new Exception("Error al Actualizar Mecanico " + ex.Message);
            }
        }
        public bool EliminaMecanico(List<CD_Parameter_SP> lista)
        {
            try
            {
                return obj_bd.ExecuteSPNonQuery("SP_ELIMINA_MECANICO", lista);
            }
            catch (Exception ex)
            {
                throw new Exception("Error al Eliminar Mecanico " + ex.Message);
            }
        }


        //SP SERVICIOS ADICIONALES
        public bool CreaServiciosAdicionales(List<CD_Parameter_SP> lista)
        {
            try
            {
                return obj_bd.ExecuteSPNonQuery("SP_CREA_SERVICIOS", lista);
            }
            catch (Exception ex)
            {
                throw new Exception("Error al Crear Servicios adicionales " + ex.Message);
            }
        }

        public bool ActualizarServiciosAdicionales(List<CD_Parameter_SP> lista)
        {
            try
            {
                return obj_bd.ExecuteSPNonQuery("SP_ACTUALIZA_SERVICIOS", lista);
            }
            catch (Exception ex)
            {
                throw new Exception("Error al Actualizar Servicios Adicionales " + ex.Message);
            }
        }
        public bool EliminaServiciosAdicionales(List<CD_Parameter_SP> lista)
        {
            try
            {
                return obj_bd.ExecuteSPNonQuery("SP_ELIMINA_SERVICIOS", lista);
            }
            catch (Exception ex)
            {
                throw new Exception("Error al Eliminar Servicios Adicionales " + ex.Message);
            }
        }


        //SP Mantenimiento
        public bool CreaMantenimiento(List<CD_Parameter_SP> lista)
        {
            try
            {
                return obj_bd.ExecuteSPNonQuery("SP_CREA_MANTENIMIENTO", lista);
            }
            catch (Exception ex)
            {
                throw new Exception("Error al Crear Mantenimiento " + ex.Message);
            }
        }

        public bool ActualizarMantenimiento(List<CD_Parameter_SP> lista)
        {
            try
            {
                return obj_bd.ExecuteSPNonQuery("SP_ACTUALIZA_MANTENIMIENTO", lista);
            }
            catch (Exception ex)
            {
                throw new Exception("Error al Actualizar el Mantenimiento " + ex.Message);
            }
        }

        public DataTable getListaMantenimiento()
        {
            List<CD_Parameter_SP> lista = new List<CD_Parameter_SP>();
            return obj_bd.ExecuteSPQuery("SP_GET_MANTENIMIENTO", lista);
        }

        public bool EliminaMantenimiento(List<CD_Parameter_SP> lista)
        {
            try
            {
                return obj_bd.ExecuteSPNonQuery("SP_ELIMINA_MANTENIMIENTO", lista);
            }
            catch (Exception ex)
            {
                throw new Exception("Error al Eliminar Mantenimiento " + ex.Message);
            }
        }
    }
}

