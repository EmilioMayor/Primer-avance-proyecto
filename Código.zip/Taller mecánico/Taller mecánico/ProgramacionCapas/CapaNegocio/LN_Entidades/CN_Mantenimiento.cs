﻿using CapaDatos.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio.LN_Entidades
{
    public class CN_Mantenimiento
    {
        private Interface_Negocio objIntMantenimiento = new Interface_Negocio();
        int id;
        DateTime fecha;
        string nombreCliente;
        string placaVehiculo;
        string marcaVehiculo;
        string modeloVehiculo;
        string colorVehiculo;
        string nombreMecanico;
        string trabajos;
        string nombreServicios;
        double totalServicios;
        string tipoMantenimiento;
        double totalTipoMat;
        double subtotal;
        double totalPagar;


        public CN_Mantenimiento()
        {
            id = 0;
            nombreCliente = string.Empty;
            nombreMecanico = string.Empty; 
            trabajos = string.Empty;
            placaVehiculo = string.Empty;
            marcaVehiculo = string.Empty;
            modeloVehiculo = string.Empty; 
            colorVehiculo = string.Empty;
            nombreServicios = string.Empty;
            totalServicios = 0;
            tipoMantenimiento = string.Empty;
            subtotal = 0;
            totalPagar = 0;
           
        }

        public CN_Mantenimiento(int id, DateTime fecha, string nombreCliente, string placaVehiculo, string marcaVehiculo, string modeloVehiculo, string colorVehiculo, string nombreMecanico, string trabajos, string nombreServicios, double totalServicios, string tipoMantenimiento, double totalTipoMat, double subtotal, double totalPagar)
        {
            this.id = id;
            this.fecha = fecha;
            this.nombreCliente = nombreCliente;
            this.placaVehiculo = placaVehiculo;
            this.marcaVehiculo = marcaVehiculo;
            this.modeloVehiculo = modeloVehiculo;
            this.colorVehiculo = colorVehiculo;
            this.nombreMecanico = nombreMecanico;
            this.trabajos = trabajos;
            this.nombreServicios = nombreServicios;
            this.totalServicios = totalServicios;
            this.tipoMantenimiento = tipoMantenimiento;
            this.totalTipoMat = totalTipoMat;
            this.subtotal = subtotal;
            this.totalPagar = totalPagar;
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public DateTime Fecha
        {
            get { return fecha; }
            set { fecha = value; }
        }

        public string NombreCliente
        {
            get { return nombreCliente; }
            set { nombreCliente = value; }
        }

        public string PlacaVehiculo
        {
            get { return placaVehiculo; }
            set { placaVehiculo = value; }
        }

        public string MarcaVehiculo
        {
            get { return marcaVehiculo; }
            set { marcaVehiculo = value; }
        }

        public string ModeloVehiculo
        {
            get { return modeloVehiculo; }
            set { modeloVehiculo = value; }
        }

        public string ColorVehiculo
        {
            get { return colorVehiculo; }
            set { colorVehiculo = value; }
        }

        public string NombreMecanico
        {
            get { return nombreMecanico; }
            set { nombreMecanico = value; }
        }

        public string Trabajos
        {
            get { return trabajos; }
            set { trabajos = value; }
        }

        public string NombreServicios
        {
            get { return nombreServicios; }
            set { nombreServicios = value; }
        }

        public double TotalServicios
        {
            get { return totalServicios; }
            set { totalServicios = value; }
        }

        public string TipoMantenimiento
        {
            get { return tipoMantenimiento; }
            set { tipoMantenimiento = value; }
        }

        public double TotalTipoMat
        {
            get { return totalTipoMat; }
            set { totalTipoMat = value; }
        }

        public double Subtotal
        {
            get { return subtotal; }
            set { subtotal = value; }
        }

        public double TotalPagar
        {
            get { return totalPagar; }
            set { totalPagar = value; }
        }


        public DataTable getListaMantenimiento()
        {      
            try
            {
                return objIntMantenimiento.getListaMantenimiento();
            }
            catch (Exception e)
            {
                throw new Exception("Error al obtener listado de Mantenimiento -> " + e.Message);
            }
        }

        public bool GuardarMantenimiento()
        {
            try
            {
                List<CD_Parameter_SP> lista = new List<CD_Parameter_SP>();
                lista.Add(new CD_Parameter_SP("@fecha", this.Fecha, SqlDbType.Date));
                lista.Add(new CD_Parameter_SP("@nombre_cliente", this.NombreCliente, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@placa_vehiculo", this.PlacaVehiculo, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@marca_vehiculo", this.MarcaVehiculo, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@modelo_vehiculo", this.ModeloVehiculo, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@color_vehiculo", this.ColorVehiculo, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@nombre_mecanico", this.NombreMecanico, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@trabajos", this.Trabajos, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@nombre_servicios", this.NombreServicios, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@Total_servicios", this.TotalServicios, SqlDbType.Decimal));
                lista.Add(new CD_Parameter_SP("@Tipo_Mantenimiento", this.TipoMantenimiento, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@total_tipo_mat", this.TotalTipoMat, SqlDbType.Decimal));
                lista.Add(new CD_Parameter_SP("@subtotal", this.Subtotal, SqlDbType.Decimal));
                lista.Add(new CD_Parameter_SP("@total_pagar", this.TotalPagar, SqlDbType.Decimal));               

                return objIntMantenimiento.CreaMantenimiento(lista);
            }
            catch (Exception e)
            {
                throw new Exception("Error al Guardar Datos de Mantenimiento -> " + e.Message);
            }
        }

        public bool ActualizarMantenimiento()
        {
            try
            {
                List<CD_Parameter_SP> lista = new List<CD_Parameter_SP>();
                lista.Add(new CD_Parameter_SP("@id", this.Id, SqlDbType.Int));
                lista.Add(new CD_Parameter_SP("@fecha", this.Fecha, SqlDbType.Date));
                lista.Add(new CD_Parameter_SP("@nombre_cliente", this.NombreCliente, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@placa_vehiculo", this.PlacaVehiculo, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@marca_vehiculo", this.MarcaVehiculo, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@modelo_vehiculo", this.ModeloVehiculo, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@color_vehiculo", this.ColorVehiculo, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@nombre_mecanico", this.NombreMecanico, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@trabajos", this.Trabajos, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@nombre_servicios", this.NombreServicios, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@Total_servicios", this.TotalServicios, SqlDbType.Decimal));
                lista.Add(new CD_Parameter_SP("@Tipo_Mantenimiento", this.TipoMantenimiento, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@total_tipo_mat", this.TotalTipoMat, SqlDbType.Decimal));
                lista.Add(new CD_Parameter_SP("@subtotal", this.Subtotal, SqlDbType.Decimal));
                lista.Add(new CD_Parameter_SP("@total_pagar", this.TotalPagar, SqlDbType.Decimal));

                return objIntMantenimiento.ActualizarMantenimiento(lista);
            }
            catch (Exception e)
            {
                throw new Exception("Error al Guardar Datos de Mantenimiento -> " + e.Message);
            }
        }

        public bool EliminarMantenimiento()
        {
            try
            {
                List<CD_Parameter_SP> lista = new List<CD_Parameter_SP>();
                lista.Add(new CD_Parameter_SP("@IdMantenimiento", this.Id, SqlDbType.Int));

                return objIntMantenimiento.EliminaMantenimiento(lista);
            }
            catch (Exception e)
            {
                throw new Exception("Error al Eliminar Datos del Mantenimiento -> " + e.Message);
            }
        }
    }

}
