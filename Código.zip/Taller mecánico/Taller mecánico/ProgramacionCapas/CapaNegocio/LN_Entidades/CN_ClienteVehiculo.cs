﻿using CapaDatos.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio.LN_Entidades
{
    public class CN_ClienteVehiculo
    {
        private Interface_Negocio objIntClienteVehiculo = new Interface_Negocio();
        private int id;
        private string nombres;
        private string apellidos;
        private string cedula;
        private int celular;
        private string correo;
        private string placa;
        private string marca;
        private string modelo;
        private string color;

        public CN_ClienteVehiculo()
        {
            id = 0;
            nombres = string.Empty;
            apellidos = string.Empty;
            cedula = string.Empty;
            celular = 0;
            correo = string.Empty;
            placa = string.Empty;
            marca = string.Empty;
            modelo = string.Empty;
            color = string.Empty;
        }

        public CN_ClienteVehiculo(int id, string nombres, string apellidos, string cedula, int celular, string correo, string placa, string marca, string modelo, string color)
        {
            this.id = id;
            this.nombres = nombres;
            this.apellidos = apellidos;
            this.cedula = cedula;
            this.celular = celular;
            this.correo = correo;
            this.placa = placa;
            this.marca = marca;
            this.modelo = modelo;
            this.color = color;
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Nombres
        {
            get { return nombres; }
            set { nombres = value; }
        }

        public string Apellidos
        {
            get { return apellidos; }
            set { apellidos = value; }
        }

        public string Cedula
        {
            get { return cedula; }
            set { cedula = value; }
        }

        public int Celular
        {
            get { return celular; }
            set { celular = value; }
        }

        public string Correo
        {
            get { return correo; }
            set { correo = value; }
        }
        public string Placa
        {
            get { return placa; }
            set { placa = value; }
        }

        public string Marca
        {
            get { return marca; }
            set { marca = value; }
        }

        public string Modelo
        {
            get { return modelo; }
            set { modelo = value; }
        }

        public string Color
        {
            get { return color; }
            set { color = value; }
        }
     

        public DataTable getListadoClienteVehiculo()
        {
            try
            {
                return objIntClienteVehiculo.getListaClienteVehiculo();
            }
            catch (Exception e)
            {
                throw new Exception("Error al obtener listado de cliente y vehiculo -> " + e.Message);
            }
        }

        public bool GuardarClienteVehiculo(CN_ClienteVehiculo clienteVehiculo)
        {

            try
            {
                List<CD_Parameter_SP> lista = new List<CD_Parameter_SP>();
                lista.Add(new CD_Parameter_SP("@nombres", clienteVehiculo.Nombres, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@apellidos", clienteVehiculo.Apellidos, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@cedula", clienteVehiculo.Cedula, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@celular", clienteVehiculo.Celular, SqlDbType.BigInt));
                lista.Add(new CD_Parameter_SP("@correo", clienteVehiculo.Correo, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@placa", clienteVehiculo.Placa, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@marca", clienteVehiculo.Marca, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@modelo", clienteVehiculo.Modelo, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@color", clienteVehiculo.Color, SqlDbType.Text));

                return objIntClienteVehiculo.CreaClienteVehiculo(lista);

            }
            catch (Exception e)
            {
                throw new Exception("Error al Guardar Datos de Cliente y vehiculo -> " + e.Message);
            }

        }

        public bool ActualizarClienteVehiculo(CN_ClienteVehiculo clienteVehiculo)
        {
            try
            {
                List<CD_Parameter_SP> lista = new List<CD_Parameter_SP>();
                lista.Add(new CD_Parameter_SP("@id", clienteVehiculo.Id, SqlDbType.Int));
                lista.Add(new CD_Parameter_SP("@nombres", clienteVehiculo.Nombres, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@apellidos", clienteVehiculo.Apellidos, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@cedula", clienteVehiculo.Cedula, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@celular", clienteVehiculo.Celular, SqlDbType.BigInt));
                lista.Add(new CD_Parameter_SP("@correo", clienteVehiculo.Correo, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@placa", clienteVehiculo.Placa, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@marca", clienteVehiculo.Marca, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@modelo", clienteVehiculo.Modelo, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@color", clienteVehiculo.Color, SqlDbType.Text));

                return objIntClienteVehiculo.ActualizarClienteVehiculo(lista);

            }
            catch (Exception e)
            {
                throw new Exception("Error al Actualizar Datos de Cliente y vehiculo -> " + e.Message);
            }

        }
        public bool EliminarClienteVehiculo(CN_ClienteVehiculo clienteVehiculo)
        {
            try
            {
                List<CD_Parameter_SP> lista = new List<CD_Parameter_SP>();
                lista.Add(new CD_Parameter_SP("@IdClienteVehiculo", clienteVehiculo.Id, SqlDbType.Int));

                return objIntClienteVehiculo.EliminaClienteVehiculo(lista);
            }
            catch (Exception e)
            {
                throw new Exception("Error al Eliminar Datos de Cliente y vehiculo -> " + e.Message);
            }
        }


    }
}
 
