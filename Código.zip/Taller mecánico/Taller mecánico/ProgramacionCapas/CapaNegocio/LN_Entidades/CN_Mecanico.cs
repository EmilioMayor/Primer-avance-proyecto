﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaDatos.ExecuteSQL;
using CapaDatos.Interface;

namespace CapaNegocio.LN_Entidades
{
    public class CN_Mecanico
    {
        //private ExecuteSQL objCapaDatos = new ExecuteSQL();

        private Interface_Negocio objIntMecanico = new Interface_Negocio();
        private int id;
        private string nombres;
        private string apellidos;
        private string cedula;
        private int celular;
        private string correo;
        public CN_Mecanico()
        {
            id = 0;
            nombres = string.Empty;
            apellidos = string.Empty;
            cedula = string.Empty;
            celular = 0;
            correo = string.Empty;
        }

        public CN_Mecanico(int id, string nombres, string apellidos, string cedula, int celular, string correo)
        {
            this.id = id;
            this.nombres = nombres;
            this.apellidos = apellidos;
            this.cedula = cedula;
            this.celular = celular;
            this.correo = correo;
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Nombres
        {
            get { return nombres; }
            set { nombres = value; }
        }

        public string Apellidos
        {
            get { return apellidos; }
            set { apellidos = value; }
        }

        public string Cedula
        {
            get { return cedula; }
            set { cedula = value; }
        }

        public int Celular
        {
            get { return celular; }
            set { celular = value; }
        }

        public string Correo
        {
            get { return correo; }
            set { correo = value; }
        }

        public DataTable getListaNombres()
        {
            try
            {
                return objIntMecanico.getNombresCompletosMecanico();
            }
            catch (Exception e)
            {
                throw new Exception("Error al obtener nombres completos del cliente -> " + e.Message);
            }
        }

        public DataTable getListadoMecanico()
        {
            try
            {
                return objIntMecanico.getListaMecanico();
            }
            catch (Exception e)
            {
                throw new Exception("Error al obtener listado de mecanico -> " + e.Message);
            }
        }

        public bool GuardarMecanico(CN_Mecanico mecanico)
        {
            try
            {
                List<CD_Parameter_SP> lista = new List<CD_Parameter_SP>();
                lista.Add(new CD_Parameter_SP("@nombres", mecanico.Nombres, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@apellidos", mecanico.Apellidos, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@cedula", mecanico.Cedula, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@celular", mecanico.Celular, SqlDbType.BigInt));
                lista.Add(new CD_Parameter_SP("@correo", mecanico.Correo, SqlDbType.Text));

                return objIntMecanico.CreaMecanico(lista);

            }
            catch (Exception e)
            {
                throw new Exception("Error al Guardar Datos de Mecanico -> " + e.Message);
            }

        }

        public bool ActualizarMecanico(CN_Mecanico mecanico)
        {
            try
            {
                List<CD_Parameter_SP> lista = new List<CD_Parameter_SP>();
                lista.Add(new CD_Parameter_SP("@id", mecanico.Id, SqlDbType.Int));
                lista.Add(new CD_Parameter_SP("@nombres", mecanico.Nombres, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@apellidos", mecanico.Apellidos, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@cedula", mecanico.Cedula, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@celular", mecanico.Celular, SqlDbType.BigInt));
                lista.Add(new CD_Parameter_SP("@correo", mecanico.Correo, SqlDbType.Text));

                return objIntMecanico.ActualizarMecanico(lista);

            }
            catch (Exception e)
            {
                throw new Exception("Error al Actualizar Datos de Mecanico -> " + e.Message);
            }

        }
        public bool EliminarMecanico(CN_Mecanico mecanico)
        {
            try
            {
                List<CD_Parameter_SP> lista = new List<CD_Parameter_SP>();
                lista.Add(new CD_Parameter_SP("@IdMecanico", mecanico.Id, SqlDbType.Int));

                return objIntMecanico.EliminaMecanico(lista);
            }
            catch (Exception e)
            {
                throw new Exception("Error al Eliminar Datos de Mecanico -> " + e.Message);
            }
        }
    }
}
