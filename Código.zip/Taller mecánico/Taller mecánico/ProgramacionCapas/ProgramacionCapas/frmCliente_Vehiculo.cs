﻿using CapaNegocio.LN_Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class frmCliente_Vehiculo : Form
    {
        CN_ClienteVehiculo obj_cn_cliente_vehiculo = new CN_ClienteVehiculo();
        private bool is_nuevo = false;


        public frmCliente_Vehiculo()
        {
            InitializeComponent();
        }

        private void frmCliente_Vehiculo_Load(object sender, EventArgs e)
        {
            LoadDgvClienteVehiculo();
        }

        private void setearControles()
        {
            txtId.Text = string.Empty;
            txtNombres.Text = string.Empty;
            txtApellidos.Text = string.Empty;
            txtCedula.Text = string.Empty;
            txtCelular.Text = string.Empty;
            txtCorreos.Text = string.Empty;
            txtPlaca.Text = string.Empty;
            txtMarca.Text = string.Empty;
            txtModelo.Text = string.Empty;
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            is_nuevo = true;
            setearControles();
            btnGrabar.Enabled = true;
            btnEliminar.Enabled = false;
            btnNuevo.Enabled = false;
        }

        private void btnGrabar_Click(object sender, EventArgs e)
        {
            try
            {
                if (is_nuevo)
                {
                    obj_cn_cliente_vehiculo.Nombres = txtNombres.Text;
                    obj_cn_cliente_vehiculo.Apellidos = txtApellidos.Text;
                    obj_cn_cliente_vehiculo.Cedula = txtCedula.Text;
                    obj_cn_cliente_vehiculo.Celular = Convert.ToInt32(txtCelular.Text);
                    obj_cn_cliente_vehiculo.Correo = txtCorreos.Text;
                    obj_cn_cliente_vehiculo.Placa = txtPlaca.Text;
                    obj_cn_cliente_vehiculo.Marca = txtMarca.Text;
                    obj_cn_cliente_vehiculo.Modelo = txtModelo.Text;
                    obj_cn_cliente_vehiculo.Color = txtColor.Text;
                    if (obj_cn_cliente_vehiculo.GuardarClienteVehiculo(obj_cn_cliente_vehiculo))
                        MessageBox.Show("Registro Guardado");
                    else
                        MessageBox.Show("Registro No pudo Grabarse");

                    LoadDgvClienteVehiculo();
                    btnGrabar.Enabled = false;
                    btnNuevo.Enabled = true;
                    is_nuevo = false;
                }
                else
                {
                    obj_cn_cliente_vehiculo.Id = Convert.ToInt16(txtId.Text);
                    obj_cn_cliente_vehiculo.Nombres = txtNombres.Text;
                    obj_cn_cliente_vehiculo.Apellidos = txtApellidos.Text;
                    obj_cn_cliente_vehiculo.Cedula = txtCedula.Text;
                    obj_cn_cliente_vehiculo.Celular = Convert.ToInt32(txtCelular.Text);
                    obj_cn_cliente_vehiculo.Correo = txtCorreos.Text;
                    obj_cn_cliente_vehiculo.Placa = txtPlaca.Text;
                    obj_cn_cliente_vehiculo.Marca = txtMarca.Text;
                    obj_cn_cliente_vehiculo.Modelo = txtModelo.Text;
                    obj_cn_cliente_vehiculo.Color = txtColor.Text;

                    if (obj_cn_cliente_vehiculo.ActualizarClienteVehiculo(obj_cn_cliente_vehiculo))
                    {
                        MessageBox.Show("Registro Actualizado con Exito");
                        LoadDgvClienteVehiculo();
                    }
                    else
                        MessageBox.Show("Registro NO pudo ser Actualizado");
                    btnGrabar.Enabled = false;
                    btnEliminar.Enabled = false;
                    btnNuevo.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LoadDgvClienteVehiculo()
        {
            try
            {
                dgvClienteVehiculo.DataSource = obj_cn_cliente_vehiculo.getListadoClienteVehiculo();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dgvClienteVehiculo_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            var fila = e.RowIndex;
            if (fila > 0)
            {
                txtId.Text = dgvClienteVehiculo.Rows[fila].Cells["ID"].Value.ToString();
                txtNombres.Text = dgvClienteVehiculo.Rows[fila].Cells["NOMBRES"].Value.ToString();
                txtApellidos.Text = dgvClienteVehiculo.Rows[fila].Cells["APELLIDOS"].Value.ToString();
                txtCedula.Text = dgvClienteVehiculo.Rows[fila].Cells["CEDULA"].Value.ToString();
                txtCelular.Text = dgvClienteVehiculo.Rows[fila].Cells["CELULAR"].Value.ToString();
                txtCorreos.Text = dgvClienteVehiculo.Rows[fila].Cells["CORREO"].Value.ToString();
                txtPlaca.Text = dgvClienteVehiculo.Rows[fila].Cells["PLACA"].Value.ToString();
                txtMarca.Text = dgvClienteVehiculo.Rows[fila].Cells["MARCA"].Value.ToString();
                txtModelo.Text = dgvClienteVehiculo.Rows[fila].Cells["MODELO"].Value.ToString();
                txtColor.Text = dgvClienteVehiculo.Rows[fila].Cells["COLOR"].Value.ToString();

                btnNuevo.Enabled = false;
                btnGrabar.Enabled = true;
                btnEliminar.Enabled = true;
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                obj_cn_cliente_vehiculo.Id = Convert.ToInt16(txtId.Text);
                if (obj_cn_cliente_vehiculo.EliminarClienteVehiculo(obj_cn_cliente_vehiculo))
                {
                    MessageBox.Show("Registro Eliminado con Exito");
                    LoadDgvClienteVehiculo();
                }
                else
                    MessageBox.Show("No se Pudo Eliminar el Registro");
                btnGrabar.Enabled = false;
                btnEliminar.Enabled = false;
                btnNuevo.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSeleccionar_Click(object sender, EventArgs e)
        {
            string Nombres = ObtenerNombreCompleto();
            string Placa = ObtenerPlaca();
            string Marca = ObtenerMarca();
            string Modelo = ObtenerModelo();
            string Color = ObtenerColor();
            DialogResult = DialogResult.OK;
            Close();
        }


        public string ObtenerNombreCompleto()
        {
            if (dgvClienteVehiculo.SelectedRows.Count > 0)
            {
                string nombreCompleto = dgvClienteVehiculo.SelectedRows[0].Cells["NOMBRES"].Value.ToString()  
                    + dgvClienteVehiculo.SelectedRows[0].Cells["APELLIDOS"].Value.ToString();
                return nombreCompleto;
            }
            else
            {
                return "N/A";
            }
        }

        public string ObtenerPlaca()
        {
            if (dgvClienteVehiculo.SelectedRows.Count > 0)
            {
                string nombre = dgvClienteVehiculo.SelectedRows[0].Cells["PLACA"].Value.ToString();
                return nombre;
            }
            else
            {
                return "N/A";
            }
        }

        public string ObtenerMarca()
        {
            if (dgvClienteVehiculo.SelectedRows.Count > 0)
            {
                string nombre = dgvClienteVehiculo.SelectedRows[0].Cells["MARCA"].Value.ToString();
                return nombre;
            }
            else
            {
                return "N/A";
            }
        }

        public string ObtenerModelo()
        {
            if (dgvClienteVehiculo.SelectedRows.Count > 0)
            {
                string nombre = dgvClienteVehiculo.SelectedRows[0].Cells["MODELO"].Value.ToString();
                return nombre;
            }
            else
            {
                return "N/A";
            }
        }

        public string ObtenerColor()
        {
            if (dgvClienteVehiculo.SelectedRows.Count > 0)
            {
                string nombre = dgvClienteVehiculo.SelectedRows[0].Cells["COLOR"].Value.ToString();
                return nombre;
            }
            else
            {
                return "N/A";
            }
        }

        

    }
}
