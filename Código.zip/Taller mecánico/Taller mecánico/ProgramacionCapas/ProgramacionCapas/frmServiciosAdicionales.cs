﻿using CapaNegocio.LN_Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class frmServiciosAdicionales : Form
    {
        CN_ServiciosAdicionales obj_cn_servicios_adicionales = new CN_ServiciosAdicionales();
        private bool is_nuevo = false;

        public frmServiciosAdicionales()
        {
            InitializeComponent();
            //Añadir el evento CheckedChanged de cada CheckBox
            cbAlineacion.CheckedChanged += CheckBox_CheckedChanged;
            cbCambioAceite.CheckedChanged += CheckBox_CheckedChanged;
            cbCambioBateria.CheckedChanged += CheckBox_CheckedChanged;
            cbLavado.CheckedChanged += CheckBox_CheckedChanged;
            cbReemplazoLuces.CheckedChanged += CheckBox_CheckedChanged;
        }


        private void frmServiciosAdicionales_Load(object sender, EventArgs e)
        {
            LoadDgvServicios();
            CalcularTotalServiciosAdicionales();
        }

        private void setearControles()
        {
            txtId.Text = string.Empty;
            txtTotal.Text = string.Empty;
        }

        private void CalcularTotalServiciosAdicionales()
        {
            // Definir los valores asociados a cada CheckBox
            Dictionary<CheckBox, int> valoresCheckBox = new Dictionary<CheckBox, int>
            {
                { cbAlineacion, 100 },
                { cbCambioAceite, 180 },
                { cbCambioBateria, 200 },
                { cbLavado, 80 },
                { cbReemplazoLuces, 100 }
            };

            // Calcular el total sumando los valores de los CheckBox seleccionados
            int total = 0;
            foreach (var kvp in valoresCheckBox)
            {
                if (kvp.Key.Checked)
                {
                    total += kvp.Value;
                }
            }
            // Mostrar el total en la caja de texto
            txtTotal.Text = total.ToString();
        }

        private void CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            CalcularTotalServiciosAdicionales();
        }


        private string ObtenerTipoServicioSeleccionado()
        {
            var Seleccionados = gbServiciosAdicionales.Controls.OfType<CheckBox>()
                .Where(c => c.Checked)
                .Select(c => c.Text);
            return string.Join(", ", Seleccionados);
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            is_nuevo = true;
            setearControles();
            btnGrabar.Enabled = true;
            btnEliminar.Enabled = false;
            btnNuevo.Enabled = false;
        }

        private void btnGrabar_Click(object sender, EventArgs e)
        {
            try
            {
                if (is_nuevo)
                {
                    obj_cn_servicios_adicionales.Nombre = ObtenerTipoServicioSeleccionado();
                    obj_cn_servicios_adicionales.Total = Convert.ToInt32(txtTotal.Text);
                    if (obj_cn_servicios_adicionales.GuardarServiciosAdicionales(obj_cn_servicios_adicionales))
                        MessageBox.Show("Registro Guardado");
                    else
                        MessageBox.Show("Registro No pudo Grabarse");

                    LoadDgvServicios();
                    btnGrabar.Enabled = false;
                    btnNuevo.Enabled = true;
                    is_nuevo = false;
                }
                else
                {
                    obj_cn_servicios_adicionales.Id = Convert.ToInt16(txtId.Text);
                    obj_cn_servicios_adicionales.Nombre = ObtenerTipoServicioSeleccionado();
                    obj_cn_servicios_adicionales.Total = Convert.ToInt32(txtTotal.Text);
                    if (obj_cn_servicios_adicionales.ActualizarServiciosAdicionales(obj_cn_servicios_adicionales))
                    {
                        MessageBox.Show("Registro Actualizado con Exito");
                        LoadDgvServicios();
                    }
                    else
                        MessageBox.Show("Registro NO pudo ser Actualizado");
                    btnGrabar.Enabled = false;
                    btnEliminar.Enabled = false;
                    btnNuevo.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LoadDgvServicios()
        {
            try
            {
                dgvServicios.DataSource = obj_cn_servicios_adicionales.getListadoServiciosAdicionales();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dgvServicios_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            var fila = e.RowIndex;
            if (fila > 0)
            {
                txtId.Text = dgvServicios.Rows[fila].Cells["ID"].Value.ToString();
                txtTotal.Text = dgvServicios.Rows[fila].Cells["TOTAL"].Value.ToString();

                btnNuevo.Enabled = false;
                btnGrabar.Enabled = true;
                btnEliminar.Enabled = true;
            }
        }


        private void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                obj_cn_servicios_adicionales.Id = Convert.ToInt16(txtId.Text);
                if (obj_cn_servicios_adicionales.EliminarServiciosAdicionales(obj_cn_servicios_adicionales))
                {
                    MessageBox.Show("Registro Eliminado con Exito");
                    LoadDgvServicios();
                }
                else
                    MessageBox.Show("No se Pudo Eliminar el Registro");
                btnGrabar.Enabled = false;
                btnEliminar.Enabled = false;
                btnNuevo.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSeleccionar_Click(object sender, EventArgs e)
        {
            string NombresSeleccionados = ObtenerSeleccionesServicios();
            string TotalSeleccionados = ObtenerSeleccionesTotal();
            DialogResult = DialogResult.OK;
            Close();           
        }

        public string ObtenerSeleccionesServicios()
        {
            if (dgvServicios.SelectedRows.Count > 0)
            {
                string nombre = dgvServicios.SelectedRows[0].Cells["Nombre"].Value.ToString();
                return nombre;
            }
            else
            {
                return "N/A";
            }
        }

        public string ObtenerSeleccionesTotal()
        {
            if (dgvServicios.SelectedRows.Count > 0)
            {
                //string nombre = dgvServicios.SelectedRows[0].Cells["Nombre"].Value.ToString();
                string total = dgvServicios.SelectedRows[0].Cells["Total"].Value.ToString();
                return total;
            }
            else
            {
                return "N/A";
            }
        }
    }
}
