﻿namespace CapaPresentacion
{
    partial class frmServiciosAdicionales
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtTotal = new TextBox();
            dgvServicios = new DataGridView();
            label1 = new Label();
            groupBox1 = new GroupBox();
            btnEliminar = new Button();
            btnNuevo = new Button();
            btnGrabar = new Button();
            gbServiciosAdicionales = new GroupBox();
            cbReemplazoLuces = new CheckBox();
            cbLavado = new CheckBox();
            cbCambioBateria = new CheckBox();
            cbCambioAceite = new CheckBox();
            cbAlineacion = new CheckBox();
            txtId = new TextBox();
            label2 = new Label();
            btnSeleccionar = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvServicios).BeginInit();
            groupBox1.SuspendLayout();
            gbServiciosAdicionales.SuspendLayout();
            SuspendLayout();
            // 
            // txtTotal
            // 
            txtTotal.Location = new Point(436, 117);
            txtTotal.Name = "txtTotal";
            txtTotal.ReadOnly = true;
            txtTotal.Size = new Size(135, 23);
            txtTotal.TabIndex = 22;
            // 
            // dgvServicios
            // 
            dgvServicios.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvServicios.Location = new Point(23, 191);
            dgvServicios.Name = "dgvServicios";
            dgvServicios.RowTemplate.Height = 25;
            dgvServicios.Size = new Size(754, 234);
            dgvServicios.TabIndex = 20;
            dgvServicios.CellClick += dgvServicios_CellClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(300, 120);
            label1.Name = "label1";
            label1.Size = new Size(130, 15);
            label1.TabIndex = 21;
            label1.Text = "Valor total de servicios: ";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnSeleccionar);
            groupBox1.Controls.Add(btnEliminar);
            groupBox1.Controls.Add(btnNuevo);
            groupBox1.Controls.Add(btnGrabar);
            groupBox1.Location = new Point(626, 29);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(151, 150);
            groupBox1.TabIndex = 19;
            groupBox1.TabStop = false;
            // 
            // btnEliminar
            // 
            btnEliminar.Enabled = false;
            btnEliminar.Location = new Point(28, 78);
            btnEliminar.Margin = new Padding(2);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(105, 23);
            btnEliminar.TabIndex = 30;
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = true;
            btnEliminar.Click += btnEliminar_Click;
            // 
            // btnNuevo
            // 
            btnNuevo.Location = new Point(28, 21);
            btnNuevo.Margin = new Padding(2);
            btnNuevo.Name = "btnNuevo";
            btnNuevo.Size = new Size(105, 23);
            btnNuevo.TabIndex = 28;
            btnNuevo.Text = "Nuevo";
            btnNuevo.UseVisualStyleBackColor = true;
            btnNuevo.Click += btnNuevo_Click;
            // 
            // btnGrabar
            // 
            btnGrabar.Enabled = false;
            btnGrabar.Location = new Point(28, 48);
            btnGrabar.Margin = new Padding(2);
            btnGrabar.Name = "btnGrabar";
            btnGrabar.Size = new Size(105, 23);
            btnGrabar.TabIndex = 29;
            btnGrabar.Text = "Grabar";
            btnGrabar.UseVisualStyleBackColor = true;
            btnGrabar.Click += btnGrabar_Click;
            // 
            // gbServiciosAdicionales
            // 
            gbServiciosAdicionales.Controls.Add(cbReemplazoLuces);
            gbServiciosAdicionales.Controls.Add(cbLavado);
            gbServiciosAdicionales.Controls.Add(cbCambioBateria);
            gbServiciosAdicionales.Controls.Add(cbCambioAceite);
            gbServiciosAdicionales.Controls.Add(cbAlineacion);
            gbServiciosAdicionales.Controls.Add(txtId);
            gbServiciosAdicionales.Controls.Add(label2);
            gbServiciosAdicionales.Location = new Point(23, 12);
            gbServiciosAdicionales.Name = "gbServiciosAdicionales";
            gbServiciosAdicionales.Size = new Size(240, 173);
            gbServiciosAdicionales.TabIndex = 18;
            gbServiciosAdicionales.TabStop = false;
            gbServiciosAdicionales.Text = "Servicios Adicionales";
            // 
            // cbReemplazoLuces
            // 
            cbReemplazoLuces.AutoSize = true;
            cbReemplazoLuces.Location = new Point(6, 148);
            cbReemplazoLuces.Name = "cbReemplazoLuces";
            cbReemplazoLuces.Size = new Size(165, 19);
            cbReemplazoLuces.TabIndex = 47;
            cbReemplazoLuces.Text = "Reemplazo de luces (100$)";
            cbReemplazoLuces.UseVisualStyleBackColor = true;
            // 
            // cbLavado
            // 
            cbLavado.AutoSize = true;
            cbLavado.Location = new Point(6, 124);
            cbLavado.Name = "cbLavado";
            cbLavado.Size = new Size(93, 19);
            cbLavado.TabIndex = 46;
            cbLavado.Text = "Lavado (80$)";
            cbLavado.UseVisualStyleBackColor = true;
            // 
            // cbCambioBateria
            // 
            cbCambioBateria.AutoSize = true;
            cbCambioBateria.Location = new Point(6, 99);
            cbCambioBateria.Name = "cbCambioBateria";
            cbCambioBateria.Size = new Size(158, 19);
            cbCambioBateria.TabIndex = 45;
            cbCambioBateria.Text = "Cambio de bateria (200$)";
            cbCambioBateria.UseVisualStyleBackColor = true;
            // 
            // cbCambioAceite
            // 
            cbCambioAceite.AutoSize = true;
            cbCambioAceite.Location = new Point(6, 74);
            cbCambioAceite.Name = "cbCambioAceite";
            cbCambioAceite.Size = new Size(153, 19);
            cbCambioAceite.TabIndex = 44;
            cbCambioAceite.Text = "Cambio de aceite (180$)";
            cbCambioAceite.UseVisualStyleBackColor = true;
            // 
            // cbAlineacion
            // 
            cbAlineacion.AutoSize = true;
            cbAlineacion.Location = new Point(6, 49);
            cbAlineacion.Name = "cbAlineacion";
            cbAlineacion.Size = new Size(117, 19);
            cbAlineacion.TabIndex = 43;
            cbAlineacion.Text = "Alineacion (100$)";
            cbAlineacion.UseVisualStyleBackColor = true;
            // 
            // txtId
            // 
            txtId.Location = new Point(71, 21);
            txtId.Margin = new Padding(2);
            txtId.Name = "txtId";
            txtId.ReadOnly = true;
            txtId.Size = new Size(90, 23);
            txtId.TabIndex = 42;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(47, 24);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(20, 15);
            label2.TabIndex = 41;
            label2.Text = "Id:";
            // 
            // btnSeleccionar
            // 
            btnSeleccionar.Location = new Point(28, 107);
            btnSeleccionar.Name = "btnSeleccionar";
            btnSeleccionar.Size = new Size(105, 23);
            btnSeleccionar.TabIndex = 31;
            btnSeleccionar.Text = "Seleccionar";
            btnSeleccionar.UseVisualStyleBackColor = true;
            btnSeleccionar.Click += btnSeleccionar_Click;
            // 
            // frmServiciosAdicionales
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txtTotal);
            Controls.Add(dgvServicios);
            Controls.Add(label1);
            Controls.Add(groupBox1);
            Controls.Add(gbServiciosAdicionales);
            Name = "frmServiciosAdicionales";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "frmServiciosAdicionales";
            Load += frmServiciosAdicionales_Load;
            ((System.ComponentModel.ISupportInitialize)dgvServicios).EndInit();
            groupBox1.ResumeLayout(false);
            gbServiciosAdicionales.ResumeLayout(false);
            gbServiciosAdicionales.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox txtTotal;
        private DataGridView dgvServicios;
        private Label label1;
        private GroupBox groupBox1;
        private Button btnEliminar;
        private Button btnNuevo;
        private Button btnGrabar;
        private GroupBox gbServiciosAdicionales;
        private TextBox txtId;
        private Label label2;
        private CheckBox cbReemplazoLuces;
        private CheckBox cbLavado;
        private CheckBox cbCambioBateria;
        private CheckBox cbCambioAceite;
        private CheckBox cbAlineacion;
        private Button btnSeleccionar;
    }
}