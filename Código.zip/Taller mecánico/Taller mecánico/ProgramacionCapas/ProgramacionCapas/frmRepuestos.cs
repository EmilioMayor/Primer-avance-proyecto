﻿using CapaNegocio.LN_Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class frmRepuestos : Form
    {
        CN_Repuesto obj_cn_repuesto = new CN_Repuesto();
        private bool is_nuevo = false;
        double precio = 0;
        int posicion = 0;
        int i = 1;

        public frmRepuestos()
        {
            InitializeComponent();
            cmbRepuestos.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void frmRepuestos_Load(object sender, EventArgs e)
        {
            //LoadDgvRepuesto();
        }

        private void setearControles()
        {
            txtId.Text = string.Empty;
            cmbRepuestos.Text = string.Empty;
            txtPrecio.Text = string.Empty;
            txtCantidad.Text = string.Empty;
            txtTotal.Text = string.Empty;
        }

        private void btnNuevo_Click_1(object sender, EventArgs e)
        {
            is_nuevo = true;
            setearControles();
            btnGrabar.Enabled = true;
            btnEliminar.Enabled = false;
            btnNuevo.Enabled = false;
            btnEnviar.Enabled = true;
        }

        private void btnGrabar_Click(object sender, EventArgs e)
        {
            try
            {
                // Validar que las cadenas sean números válidos
                if (!float.TryParse(txtPrecio.Text, out float precio) || !int.TryParse(txtCantidad.Text, out int cantidad))
                {
                    MessageBox.Show("El precio y la cantidad deben ser números válidos.");
                    return;
                }

                // Calcular el total
                float total = precio * cantidad;

                // Mostrar el total en el campo correspondiente
                txtTotal.Text = total.ToString();

                if ( is_nuevo)
                {
                    string nombre;
                    nombre = cmbRepuestos.Text;
                    precio = Convert.ToSingle(txtPrecio.Text);
                    cantidad = Convert.ToInt32(txtCantidad.Text);
                    total = Convert.ToSingle(txtTotal.Text);

                    dgvRepuestos.Rows.Add(i+"", nombre, precio, cantidad, total);
                    i = i + 1;
                    btnGrabar.Enabled = false;
                    btnNuevo.Enabled = true;
                    is_nuevo = false;
                }
                else
                {
                    string nombre;                   
                    nombre = cmbRepuestos.Text;
                    precio = Convert.ToSingle(txtPrecio.Text);
                    cantidad = Convert.ToInt32(txtCantidad.Text);
                    total = Convert.ToSingle(txtTotal.Text);

                    dgvRepuestos[1, posicion].Value = cmbRepuestos.Text;
                    dgvRepuestos[2, posicion].Value = txtPrecio.Text;
                    dgvRepuestos[3, posicion].Value = txtCantidad.Text;
                    dgvRepuestos[4, posicion].Value = txtTotal.Text;

                    btnGrabar.Enabled = false;
                    btnNuevo.Enabled = true;
                    is_nuevo = false;
                }
                ObtenerTotal();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void dgvRepuestos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            posicion = dgvRepuestos.CurrentRow.Index;
            cmbRepuestos.Text = dgvRepuestos[1, posicion].Value.ToString();
            txtPrecio.Text = dgvRepuestos[2, posicion].Value.ToString();
            txtCantidad.Text = dgvRepuestos[3, posicion].Value.ToString();
            txtTotal.Text = dgvRepuestos[4, posicion].Value.ToString();

            btnNuevo.Enabled = false;
            btnGrabar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dgvRepuestos.SelectedRows)
            {
                dgvRepuestos.Rows.RemoveAt(row.Index);
            }
            ObtenerTotal();
        }


        private void ObtenerTotal()
        {
            // OBTENER TOTAL DE REPUESTOS CORRECTIVO
            float total = 0;

            foreach (DataGridViewRow row in dgvRepuestos.Rows)
            {
                if (row.Cells[4].Value != null && float.TryParse(row.Cells[4].Value.ToString(), out float valorCelda))
                {
                    total += valorCelda;
                }
                else
                {
                    // Manejar el caso en el que el valor no es numérico (podría ser nulo o no numérico)
                    Console.WriteLine($"La celda en la fila {row.Index} no contiene un valor numérico.");
                }
            }
            txtTot.Text = total.ToString();
        }


        private void cmbRepuestos_SelectedIndexChanged(object sender, EventArgs e)
        {
            int indice = 0;
            double precio = 0;
            indice = cmbRepuestos.SelectedIndex;
            switch (indice)
            {
                case 0:
                    precio = 15.99;
                    break;
                case 1:
                    precio = 12.99;
                    break;
                case 2:
                    precio = 29.99;
                    break;
                case 3:
                    precio = 45.99;
                    break;
                case 4:
                    precio = 89.99;
                    break;
                case 5:
                    precio = 7.99;
                    break;
                case 6:
                    precio = 59.99;
                    break;
                case 7:
                    precio = 124.99;
                    break;
                case 8:
                    precio = 34.99;
                    break;
                case 9:
                    precio = 5.99;
                    break;
            }
            txtPrecio.Text = precio.ToString();
        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            string TotalSeleccionados = ObtenerSeleccionesTotal();
            DialogResult = DialogResult.OK;
            Close();
        }

        public string ObtenerSeleccionesTotal()
        {
            string total = txtTot.Text;
            return total;
        }
    }
}
