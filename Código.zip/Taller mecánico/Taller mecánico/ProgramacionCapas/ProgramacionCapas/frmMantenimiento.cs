﻿using CapaNegocio.LN_Entidades;
using ProgramacionCapas;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class frmMantenimiento : Form
    {
        private CN_Mantenimiento obj_cn_mantenimiento = new CN_Mantenimiento();
        CN_ClienteVehiculo obj_cn_cliente_vehiculo = new CN_ClienteVehiculo();
        CN_Mecanico obj_cn_mecanico = new CN_Mecanico();
        CN_ServiciosAdicionales obj_cn_servicios_adicionales = new CN_ServiciosAdicionales();
        CN_Repuesto obj_cn_repuesto = new CN_Repuesto();

        private bool is_nuevo = false;
        double totalMantenimiento = 0;

        public frmMantenimiento()
        {
            InitializeComponent();
            rbCorrectivo.CheckedChanged += TipoMantenimiento_CheckedChanged;
            rbPreventivo.CheckedChanged += TipoMantenimiento_CheckedChanged;


            cmbMecanico.DropDownStyle = ComboBoxStyle.DropDownList;
            obj_cn_mantenimiento = new CN_Mantenimiento();

            LoadDgvMantenimiento();
            LoadDgvMecanico();
        }


        private void setearControles()
        {
            txtId.Text = string.Empty;
            txtNombre.Text = string.Empty;
            txtPlaca.Text = string.Empty;
            txtMarca.Text = string.Empty;
            txtModelo.Text = string.Empty;
            txtColor.Text = string.Empty;
            cmbMecanico.Text = string.Empty;
            rtbTrabajos.Text = string.Empty;
            rtbServicios.Text = string.Empty;
            txtTotalPreventivo.Text = string.Empty;
            txtTotalCorrectivo.Text = string.Empty;
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            setearControles();
            is_nuevo = true;
            btnGrabar.Enabled = true;
            btnEliminar.Enabled = false;
            btnNuevo.Enabled = false;
        }

        private void btnGrabar_Click(object sender, EventArgs e)
        {
            try
            {
                if (is_nuevo)
                {
                    obj_cn_mantenimiento.Fecha = dateTimePicker1.Value;
                    obj_cn_mantenimiento.NombreCliente = txtNombre.Text;
                    obj_cn_mantenimiento.PlacaVehiculo = txtPlaca.Text;
                    obj_cn_mantenimiento.MarcaVehiculo = txtMarca.Text;
                    obj_cn_mantenimiento.ModeloVehiculo = txtModelo.Text;
                    obj_cn_mantenimiento.ColorVehiculo = txtColor.Text;
                    obj_cn_mantenimiento.NombreMecanico = cmbMecanico.Text;
                    obj_cn_mantenimiento.Trabajos = rtbTrabajos.Text;
                    obj_cn_mantenimiento.NombreServicios = rtbServicios.Text;
                    obj_cn_mantenimiento.TotalServicios = Convert.ToDouble(txtTotalServicios.Text);

                    //Si se selecciona Mantenimiento correctivo
                    if (rbCorrectivo.Checked)
                    {
                        obj_cn_mantenimiento.TipoMantenimiento = rbCorrectivo.Text;
                        obj_cn_mantenimiento.TotalTipoMat = Convert.ToDouble(txtTotalCorrectivo.Text);
                    }//Si se seleciona Mantenimiuento Preventivo
                    else if (rbPreventivo.Checked)
                    {
                        obj_cn_mantenimiento.TipoMantenimiento = rbPreventivo.Text;
                        obj_cn_mantenimiento.TotalTipoMat = Convert.ToDouble(txtTotalPreventivo.Text);
                    }
                    obj_cn_mantenimiento.Subtotal = Convert.ToDouble(txtSubtotal.Text);
                    obj_cn_mantenimiento.TotalPagar = Convert.ToDouble(txtTotal.Text);


                    if (obj_cn_mantenimiento.GuardarMantenimiento())

                        MessageBox.Show("Registro Guardado");

                    else

                        MessageBox.Show("Registro No pudo Grabarse");

                    LoadDgvMantenimiento();
                    setearControles();
                    btnGrabar.Enabled = false;
                    btnNuevo.Enabled = true;
                    is_nuevo = false;

                }
                else
                {
                    obj_cn_mantenimiento.Id = Convert.ToInt16(txtId.Text);
                    obj_cn_mantenimiento.Fecha = dateTimePicker1.Value;
                    obj_cn_mantenimiento.NombreCliente = txtNombre.Text;
                    obj_cn_mantenimiento.PlacaVehiculo = txtPlaca.Text;
                    obj_cn_mantenimiento.MarcaVehiculo = txtMarca.Text;
                    obj_cn_mantenimiento.ModeloVehiculo = txtModelo.Text;
                    obj_cn_mantenimiento.ColorVehiculo = txtColor.Text;
                    obj_cn_mantenimiento.NombreMecanico = cmbMecanico.Text;
                    obj_cn_mantenimiento.Trabajos = rtbTrabajos.Text;
                    obj_cn_mantenimiento.NombreServicios = rtbServicios.Text;
                    obj_cn_mantenimiento.TotalServicios = Convert.ToDouble(txtTotalServicios.Text);

                    //Si se selecciona Mantenimiento correctivo
                    if (rbCorrectivo.Checked)
                    {
                        obj_cn_mantenimiento.TipoMantenimiento = rbCorrectivo.Text;
                        obj_cn_mantenimiento.TotalTipoMat = Convert.ToDouble(txtTotalCorrectivo.Text);
                    }//Si se seleciona Mantenimiuento Preventivo
                    else if (rbPreventivo.Checked)
                    {
                        obj_cn_mantenimiento.TipoMantenimiento = rbPreventivo.Text;
                        obj_cn_mantenimiento.TotalTipoMat = Convert.ToDouble(txtTotalPreventivo.Text);
                    }
                    obj_cn_mantenimiento.Subtotal = Convert.ToDouble(txtSubtotal.Text);
                    obj_cn_mantenimiento.TotalPagar = Convert.ToDouble(txtTotal.Text);


                    if (obj_cn_mantenimiento.ActualizarMantenimiento())
                    {
                        MessageBox.Show("Registro Actualizado con Exito");
                        LoadDgvMantenimiento();
                    }
                    else
                        MessageBox.Show("Registro No pudo Actualizarce");
                    btnGrabar.Enabled = false;
                    btnEliminar.Enabled = false;
                    btnNuevo.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void LoadDgvMantenimiento()
        {
            try
            {
                dgvMantenimiento.DataSource = obj_cn_mantenimiento.getListaMantenimiento();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dgvMantenimiento_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            var fila = e.RowIndex;
            if (fila > 0)
            {
                txtId.Text = dgvMantenimiento.Rows[fila].Cells["ID"].Value.ToString();
                dateTimePicker1.Value = DateTime.Parse(dgvMantenimiento.Rows[fila].Cells["FECHA"].Value.ToString());
                txtNombre.Text = dgvMantenimiento.Rows[fila].Cells["NOMBRE_CLIENTE"].Value.ToString();
                txtPlaca.Text = dgvMantenimiento.Rows[fila].Cells["PLACA_VEHICULO"].Value.ToString();
                txtMarca.Text = dgvMantenimiento.Rows[fila].Cells["MARCA_VEHICULO"].Value.ToString();
                txtModelo.Text = dgvMantenimiento.Rows[fila].Cells["MODELO_VEHICULO"].Value.ToString();
                txtColor.Text = dgvMantenimiento.Rows[fila].Cells["COLOR_VEHICULO"].Value.ToString();
                cmbMecanico.Text = dgvMantenimiento.Rows[fila].Cells["NOMBRE_MECANICO"].Value.ToString();
                rtbTrabajos.Text = dgvMantenimiento.Rows[fila].Cells["TRABAJOS"].Value.ToString();
                rtbServicios.Text = dgvMantenimiento.Rows[fila].Cells["NOMBRE_SERVICIOS"].Value.ToString();
                txtTotalServicios.Text = dgvMantenimiento.Rows[fila].Cells["TOTAL_SERVICIOS"].Value.ToString();
                // Obtén el tipo de mantenimiento y el total de servicios desde el DataGridView
                string tipoMantenimiento = dgvMantenimiento.Rows[fila].Cells["TIPO_MANTENIMIENTO"].Value.ToString();
                double totalMantenimiento = Convert.ToDouble(dgvMantenimiento.Rows[fila].Cells["TOTAL_TIPO_MAT"].Value);

                // Asigna el tipo de mantenimiento al RadioButton correspondiente
                if (tipoMantenimiento == "Correctivo")
                {
                    rbCorrectivo.Checked = true;
                }
                else if (tipoMantenimiento == "Preventivo")
                {
                    rbPreventivo.Checked = true;
                }

                // Asigna el total de servicios al TextBox correspondiente
                if (tipoMantenimiento == "Correctivo")
                {
                    txtTotalCorrectivo.Text = totalMantenimiento.ToString();
                }
                else if (tipoMantenimiento == "Preventivo")
                {
                    txtTotalPreventivo.Text = totalMantenimiento.ToString();
                }
                txtSubtotal.Text = dgvMantenimiento.Rows[fila].Cells["SUBTOTAL"].Value.ToString();
                txtTotal.Text = dgvMantenimiento.Rows[fila].Cells["TOTAL_PAGAR"].Value.ToString();

                btnNuevo.Enabled = false;
                btnGrabar.Enabled = true;
                btnEliminar.Enabled = true;
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                obj_cn_mantenimiento.Id = Convert.ToInt16(txtId.Text);
                if (obj_cn_mantenimiento.EliminarMantenimiento())
                {
                    MessageBox.Show("Registro Eliminado con Exito");
                    LoadDgvMantenimiento();
                }
                else
                    MessageBox.Show("No se Pudo Eliminar el Registro");
                btnGrabar.Enabled = false;
                btnEliminar.Enabled = false;
                btnNuevo.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void LoadDgvMecanico()
        {
            try
            {
                DataTable dtMecanico = obj_cn_mecanico.getListaNombres();
                cmbMecanico.DataSource = dtMecanico;
                cmbMecanico.DisplayMember = "nombrecompleto";

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar Clientes: " + ex.Message);
            }
        }


        //BUSCAR CLIENTES
        private void btnCliente_Click(object sender, EventArgs e)
        {
            frmCliente_Vehiculo frmCliente_Vehiculo = new frmCliente_Vehiculo();
            if (frmCliente_Vehiculo.ShowDialog() == DialogResult.OK)
            {
                txtNombre.Text = frmCliente_Vehiculo.ObtenerNombreCompleto();
                txtPlaca.Text = frmCliente_Vehiculo.ObtenerPlaca();
                txtMarca.Text = frmCliente_Vehiculo.ObtenerMarca();
                txtModelo.Text = frmCliente_Vehiculo.ObtenerModelo();
                txtColor.Text = frmCliente_Vehiculo.ObtenerColor();
            }
        }


        //SERVICIOS ALMACENADOS
        private void btnServiciosAdicionales_Click(object sender, EventArgs e)
        {
            frmServiciosAdicionales frmServiciosAdicionales = new frmServiciosAdicionales();
            if (frmServiciosAdicionales.ShowDialog() == DialogResult.OK)
            {
                txtTotalServicios.Text = frmServiciosAdicionales.ObtenerSeleccionesTotal();
                rtbServicios.Text = frmServiciosAdicionales.ObtenerSeleccionesServicios();
            }
        }


        //TIPO DE MANTENIMIENTO
        private void TipoMantenimiento_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton radioButton = sender as RadioButton;

            if (radioButton.Checked)
            {
                double totalMantenimiento = 0;
                if (radioButton == rbCorrectivo)
                {
                    lbTotalTipoMant.Visible = true;
                    txtTotalPreventivo.Visible = false;
                    txtTotalCorrectivo.Visible = true;
                    txtTotalPreventivo.Text = string.Empty;
                    txtTotalCorrectivo.Text = string.Empty;
                }
                else if (radioButton == rbPreventivo)
                {
                    lbTotalTipoMant.Visible = true;
                    txtTotalPreventivo.Visible = true;
                    txtTotalCorrectivo.Visible = false;
                    txtTotalPreventivo.Text = string.Empty;
                    txtTotalCorrectivo.Text = string.Empty;
                }
            }
        }


        private void rbCorrectivo_Click(object sender, EventArgs e)
        {
            frmRepuestos frmRepuestos = new frmRepuestos();
            if (frmRepuestos.ShowDialog() == DialogResult.OK)
            {
                txtTotalCorrectivo.Text = frmRepuestos.ObtenerSeleccionesTotal();
            }
        }


        //Calcular subtotal y total a pagar creo que lo puedes hacer de una mejor forma 
        private void CalcularSubtotalYTotal()
        {
            if (rbCorrectivo.Checked)
            {
                if (double.TryParse(txtTotalCorrectivo.Text, out double totalCorrectivo))
                {
                    totalMantenimiento = totalCorrectivo + Convert.ToSingle(txtTotalServicios.Text);
                }
            }
            else if (rbPreventivo.Checked)
            {
                // Asignar el valor de txtTotalServicios a txtTotalPreventivo
                txtTotalPreventivo.Text += 100;

                // Tomar el valor de txtTotalPreventivo como parte del total de Preventivo
                if (double.TryParse(txtTotalPreventivo.Text, out double totalPreventivo))
                {
                    totalMantenimiento = totalPreventivo + Convert.ToSingle(txtTotalServicios.Text);
                }
            }


            // Calcular IVA y totales
            double iva = totalMantenimiento * 0.12;
            double subtotal = totalMantenimiento;
            double total = subtotal + iva;


            // Mostrar resultados
            txtSubtotal.Text = subtotal.ToString();
            txtTotal.Text = total.ToString();
        }


        private void frmMantenimiento_Load(object sender, EventArgs e)
        {
            LoadDgvMantenimiento();

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            CalcularSubtotalYTotal();
        }


        //MOSTRAR DATOS
        private void MostrarDatos()
        {
            DataGridViewRow fila = dgvMantenimiento.CurrentRow;

            if (fila != null)
            {
                string id = fila.Cells["ID"].Value?.ToString() ?? "N/A";
                string fecha = fila.Cells["FECHA"].Value?.ToString() ?? "N/A";
                string cliente = fila.Cells["NOMBRE_CLIENTE"].Value?.ToString() ?? "N/A";
                string placa = fila.Cells["PLACA_VEHICULO"].Value?.ToString() ?? "N/A";
                string marca = fila.Cells["MARCA_VEHICULO"].Value?.ToString() ?? "N/A";
                string modelo = fila.Cells["MODELO_VEHICULO"].Value?.ToString() ?? "N/A";
                string color = fila.Cells["COLOR_VEHICULO"].Value?.ToString() ?? "N/A";
                string mecanico = fila.Cells["NOMBRE_MECANICO"].Value?.ToString() ?? "N/A";
                string trabajos = fila.Cells["TRABAJOS"].Value?.ToString() ?? "N/A";
                string servicios = fila.Cells["NOMBRE_SERVICIOS"].Value?.ToString() ?? "N/A";
                string totalServicios = fila.Cells["TOTAL_SERVICIOS"].Value?.ToString() ?? "N/A";
                string tipoMantenimiento = fila.Cells["TIPO_MANTENIMIENTO"].Value?.ToString() ?? "N/A";
                string totalMantenimiento = fila.Cells["TOTAL_TIPO_MAT"].Value?.ToString() ?? "N/A";
                string subtotal = fila.Cells["SUBTOTAL"].Value?.ToString() ?? "N/A";
                string total = fila.Cells["TOTAL_PAGAR"].Value?.ToString() ?? "N/A";



                // Construir el mensaje con los datos específicos
                string mensaje = $"Id de la factura: {id}" +
                    $"\nFecha de la factura: {fecha}" +
                    $"\nNombre del cliente: {cliente}" +
                    $"\nPlaca del vehiculo: {placa}" +
                    $"\nMarca del vehiculo: {marca}" +
                    $"\nModelo del vehiculo: {modelo}" +
                    $"\nColor del vehiculo: {color}" +
                    $"\nNombre del mecanico: {mecanico}" +
                    $"\nTrabajos realizados: {trabajos}" +
                    $"\nServicios Adicionales: {servicios}" +
                    $"\nTotal servicios adicionales: {totalServicios}" +
                    $"\nTipo de mantenimiento: {tipoMantenimiento}" +
                    $"\nTotal de mantenimiento: {totalMantenimiento}" +
                    $"\nSubtotal: {subtotal}" +
                    $"\nTotal a pagar: {total}";

                MessageBox.Show(mensaje, "Datos a mostrar", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("No hay fila seleccionada.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
    }

        private void dgvMantenimiento_DoubleClick(object sender, EventArgs e)
        {
            MostrarDatos();
        }
    }
}

